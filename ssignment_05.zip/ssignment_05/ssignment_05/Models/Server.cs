﻿    namespace ssignment_05.Models
    {
        public class Server
        {
            public int Id { get; set; }
            public string Name { get; set; }
            public string City { get; set; }
            public bool IsOnline { get; set; }
        }
    }


